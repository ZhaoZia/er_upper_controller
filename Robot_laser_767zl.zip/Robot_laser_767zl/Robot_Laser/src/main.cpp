// /*
//  * rosserial Subscriber Example
//  * Blinks an LED on callback
//  */
#include "mbed.h"


#include <ros.h>
//#include <std_msgs/Empty.h>
#include <sensor_msgs/Joy.h>
#include <std_msgs/Int32.h>
#include <std_msgs/std_msgs_String.h>
#include "vesc.h"
#include "Servo.h"



//vesc
int can_id_0 = 68;
int can_id_1 = 70;
int can_id_2 = 50; //angle

bool test_state = false;


//false: auto mode 
bool mode = false;
DigitalOut mode_display(D13);

char str[30];


//shooter
unsigned target = 0;
float target_degree = 0;
int16_t target_rpm = 1000;
float target_angle = 0;

void degree_driver(int input);
//max angle: +- 10
//max degree: +- 2.5



int can_baud = 500000;
// define the can bus object
CAN can(PD_0, PD_1, can_baud); // (choose one)
vesc _vesc1;

Ticker readTicker;

//call back of the vesc thread function 

void vesc_th() { 
    // update the vesc1 parameter once 
    _vesc1.can_read(can_id_0); 
    _vesc1.can_read(can_id_1); 
    _vesc1.can_read(can_id_2); 
}


void control_cmd(){   
   _vesc1.set_rpm(can_id_0, target_rpm);         // set the vesc 1 erpm/rpm to 1000rpm
   _vesc1.set_rpm(can_id_1, target_rpm);         // set the vesc 1 erpm/rpm to 1000rpm
   _vesc1.set_pos(can_id_2, target_angle);         // set the vesc 1 erpm/rpm to 1000rpm
}

void reset_all(){
    target_rpm = 0;
}



//Debugging
 std_msgs::std_msgs_String str_msg;
 ros::Publisher chatter("chatter", &str_msg);

void dmesg(char* msg){
    str_msg.data = msg;
    chatter.publish( &str_msg ); }

//picker 
uint8_t pick_step= 0;
uint8_t picker(uint8_t step);

//reset
bool resetMode = false;

float getDegree(){
    if(target_degree > 45+2.5 || target_degree <45 -2.5){
        target_degree = 45;
    }
    return target_degree;
    
}

uint8_t pole = 0;
int16_t getRpm(uint8_t pole){
    if(pole == 2){
        return 29000;
    }
    else if(pole == 1){
        return -32.14285714279413*getDegree() + 25703.571428566676;
        
    }
    else if( pole == 0){
        return -11.764705882322687*getDegree() + 17782.352941175952;

    }


}


Servo shooter(PC_9);

//ros
ros::NodeHandle nh;
void joydata(const sensor_msgs::Joy &joy)
{  
    if ((joy.buttons[0] == 1)){//A
        test_state = true;
        //wait_us(100000);
        mode = !mode;
        mode_display.write(mode);
        if(mode) sprintf(str,"auto mode");
        else sprintf(str,"manual mode");
        dmesg(str);
    }
    if ((joy.buttons[5] == 1)){//shoot
        shooter.write(15);
        wait_us(2000);
        
        sprintf(str,"shoot");
        dmesg(str);
        
    }else{


        shooter.write(0);
    }
    


    if((joy.buttons[1] == 1)){//B
        
        //reset_all();
       // resetMode = !resetMode;
        if ((joy.buttons[2] == 1)){//x
            pick_step = 0;
            sprintf(str,"picker reset step:%d",pick_step);
            dmesg(str);
        }
    }
    else{
        
        if ((joy.buttons[2] == 1)){//x
            pick_step = picker(pick_step);
            sprintf(str,"picker start step:%d",pick_step);
            dmesg(str);
        }

        if(mode){
            if(joy.axes[7] == 1){
                pole = 2;
                target_rpm=  getRpm(pole);
                target_degree = 49;

            }
            else if(joy.axes[7] == -1){
                pole = 0;
                target_rpm=  getRpm(pole);
            }
            else if(joy.axes[6] == 1 || joy.axes[6] == -1){
                pole = 1;
                target_rpm = getRpm(pole);
            }
            sprintf(str,"rpm: %ld  degree: %d",target_rpm,target_degree);
            dmesg(str);
            
        }
        else{
            if(joy.axes[6] == 1){
                if(target_angle < 10){
                    target_angle +=1;
                }
            }
            else if(joy.axes[6] == -1){
                if(target_angle > -10){
                    target_angle -= 1;
                }
            }

            if(joy.axes[7] == 1){
                target_degree += 1; 
                degree_driver(1);              
                target_rpm=  getRpm(pole);

            }
            else if(joy.axes[7] == -1){
                target_degree -= 1; 
                degree_driver(-1);              
                target_rpm=  getRpm(pole);
            }

        }
        
        
    }
    
}
ros::Subscriber<sensor_msgs::Joy> sub1("joy", &joydata);




int main() {
    nh.initNode();
    nh.advertise(chatter);
    nh.subscribe(sub1);

    _vesc1.vesc_init(&can, can_baud);
    _vesc1.set_monitor_id(can_id_0);       //set up the moitoring ID of the VESC object
    _vesc1.set_monitor_id(can_id_1);       //set up the moitoring ID of the VESC object
    _vesc1.set_monitor_id(can_id_2);       //set up the moitoring ID of the VESC object
  
    shooter.attach(0);
    wait_us(2000);  

    sprintf(str,"Start");
    dmesg(str);
    while (true) {
        //_vesc1.set_rpm(can_id_0, 1000);         // set the vesc 1 erpm/rpm to 1000rpm
        //_vesc1.set_rpm(can_id_1, 1000);         // set the vesc 1 erpm/rpm to 1000rpm
        // print out the values
        //degree_driver(30);
        nh.spinOnce();  
        vesc_th();
        control_cmd();
        ThisThread::sleep_for(10ms);
    }
    



}











