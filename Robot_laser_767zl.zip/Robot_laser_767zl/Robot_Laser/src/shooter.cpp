#include "mbed.h"
#include "QEI.h"
#include "math.h"
#include <cstdio>

DigitalOut motorA1(A2);
DigitalOut motorA2(A1);
PwmOut motorAEnable(PC_8);

// Pin connections for the quadrature encoder
#define ENCODER_PIN_A PF_3
#define ENCODER_PIN_B PF_5                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               

// Create an instance of the QEI library
QEI encoder(ENCODER_PIN_A, ENCODER_PIN_B, NC, 360, QEI::X4_ENCODING); 

// Specify different pins to test printing on UART other than the console UART.
#define TARGET_TX_PIN                                                     USBTX
#define TARGET_RX_PIN                                                     USBRX
#define serial_debug true

// Create a BufferedSerial object to be used by the system I/O retarget code.
//static BufferedSerial serial_port(TARGET_TX_PIN, TARGET_RX_PIN, 115200);

float sign(float x) {
  if (x > 0) {
    return 1;
  } else if (x < 0) {
    return -1;
  } else {
    return 0;
  }
}

void degree_driver(int input) {
    //initialize as 0
    motorA1 = 0;
    motorA2 = 0;  
    motorAEnable.period(0.001);
    motorAEnable.write(0.0);
    //PID variables
    float kp = 0.5;
    float ki = 0.00000001;
    float kd = 0.03;
    int position = 0;
    //input
    float pi=3.1415926;
    input=input*2176/200;
    // Get the initial encoder position
    int prev_position = encoder.getPulses(); 
    //variables for calculating PID
    uint32_t time, difference_time;
    uint32_t time_prev = 0;
    volatile unsigned long count = 0;
    unsigned long count_prev = 0;
    float Theta, RPM, RPM_d, e, integral;
    float V, Theta_prev, e_prev, integral_prev = 0;
    int RPM_max = 250;
    int Vmax = 24;
    int Vmin = -24;
    position = encoder.getPulses(); // Get the current encoder position
    while (position!=input) {
        //wait_us(100);

        // printf("rpm%d %d %d \r\n", RPM_max,Vmax,Vmin);
        printf("pos%d inp%d\r\n", position, input);
        position = encoder.getPulses(); // Get the current encoder position
        time = HAL_GetTick();
        Theta = position / 900.0;
        difference_time = time - time_prev;
        RPM_d = RPM_max * (sin(2 * pi * 0.005 * time / 1000.0)) * sign(sin(2 * pi * 0.05 * time / 1000.0));
        if (time / 1000.0 > 100) {
            RPM_d = 0;
        }
        RPM = (Theta - Theta_prev) / (difference_time / 1000.0) * 60;
        e = RPM_d - RPM;
        integral = integral_prev + (difference_time * (e + e_prev) / 2);
        V = kp * e + ki * integral + kd * (e - e_prev) / difference_time;
        if (V > Vmax) {
            V = Vmax;
            integral = integral_prev;
        }
        if (V < Vmin) {
            V = Vmin;
            integral = integral_prev;
        }

                //printf("time:%d\r\n", Vmax);
        int PWMval = int(255 * abs(V) / Vmax);
       // printf("pwmaval0: %d\r\n", PWMval);
        if (abs(abs(position)-abs(input))<=5){
            PWMval = (PWMval > 60) ? 60 : PWMval;
        }else{
            PWMval = (PWMval > 255) ? 255 : PWMval;
        }

        //printf("postitioan: %d\r\n", position);
        //printf("pwmaval0: %d\r\n", PWMval);
        
        if (input<position) {
            //forward
            motorA2 = 0;
            motorA1 = 1;
            motorAEnable.write(float(PWMval)/255.0f);
        } else if (input>position) {
            //backward
            motorA2 = 1;
            motorA1 = 0;
            motorAEnable.write(float(PWMval)/255.0f);
        } else { 
            motorA2 = 0;
            motorA1 = 0;
            
        }      
        prev_position = position;
        Theta_prev = Theta;    
        time_prev = time;    
        integral_prev = integral;
        e_prev = e;
        //wait_us(1000);
        ThisThread::sleep_for(10ms);
    }
}


void te00st(){
    motorA1 = 0;
    motorA2 = 1;
    motorAEnable.period(0.001);
    motorAEnable.write(20/255.0f);
    int prev_position = encoder.getPulses(); // Get the initial encoder position

    while (1) {
        int position = encoder.getPulses(); // Get the current encoder position
        int direction = (position > prev_position) ? 1 : -1; // Determine the direction of rotation

        // Print the encoder position and direction to the serial interface
        printf("Position: %d, Direction: %s\r\n", position, direction > 0 ? "Forward" : "Reverse");

        prev_position = position; // Update the previous position

        // Wait for 100 milliseconds before reading the encoder again
        ThisThread::sleep_for(100ms);
    }

}
void test_encoder(){

    // Loop forevercvb n
    
        // Read the current position and speed from the QEI interface
        printf("Position: %d\n", encoder.getPulses());

        // Wait for a short time before reading again
        wait_us(1000);
    

}
