#include "PinNames.h"
#include "PinNamesTypes.h"
#include "mbed.h"

DigitalOut c1(PE_4);
DigitalOut c2(PE_5);
DigitalOut c3(PE_6);
DigitalIn btn(PG_3);

bool c1_state = true;
bool c2_state = false;
bool c3_state = true;

void updateState() {
    c1 = c1_state;
    c2 = c2_state;
    c3 = c3_state;
}

uint8_t picker(uint8_t state) {
    updateState();
    state++;
    switch(state) {
        case 1:
        c1_state = false;
        c2_state = false;
        c3_state = false;
        break;
        case 2:
        c1_state = false;
        c2_state = false;
        c3_state = true;
        break;
        case 3:
        c1_state = true;
        c2_state = false;
        c3_state = true;
        break;
        case 4:
        c1_state = true;
        c2_state = true;
        c3_state = true;
        break;
        case 5:
        c1_state = false;
        c2_state = true;
        c3_state = true;
        break;
        case 6:
        c1_state = false;
        c2_state = true;
        c3_state = false;
        break;
        case 7:
        c1_state = true;
        c2_state = true;
        c3_state = false;
        break;
        case 8:
        c1_state = true;
        c2_state = false;
        c3_state = false;
        break;
        case 9:
        c1_state = false;
        c2_state = false;
        c3_state = false;
        state = 0;
        break;
        
    }
    updateState();
    //ThisThread::sleep_for(500ms);
    return state;
}