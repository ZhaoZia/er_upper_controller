# ROS Serial library for ROS 1 Noetic

ROS Serial library for Mbed OS 6 platforms for ROS 1 Noetic 

Compiled from https://github.com/ros-drivers/rosserial/tree/0.9.1

Modified to avoid header name clashes during compiling, and to use Mbed OS 6 BufferedSerial API

To use, add the mbed-os library and this library to your program

# Special Things to note:

Use `std_msg_String` instead of `String` library.

`String` -> `std_msg_String`

```c++
#include <std_msgs/std_msgs_String.h>
```

`wait_ms` is not available anymore, use `wait_us` instead. (Where 1000 us = 1ms)

# Extra

Official library for Mbed OS 2: https://os.mbed.com/users/garyservin/code/ros_lib_melodic/

Tutorials on using the library: http://wiki.ros.org/rosserial_mbed/Tutorials

Make SURE you check the baud rate in MbedHArdware.h

```c++
 MbedHardware()
      :iostream(USBTX, USBRX) {
        baud_ = 921600;
        //iostream.set_blocking(true);
        t.start();      
    }
```
